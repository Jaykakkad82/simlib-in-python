import sys
import os
from LinkedList import LinkedList
import math
import pdb
class simlibPY:
    def __init__(self):

        # ALl definitions from Simlibdefs.h
        self.MAX_LIST = 25        # Max number of lists.
        self.MAX_ATTR = 10         # Max number of attributes.
        self.MAX_SVAR = 25         # Max number of sampst variables.
        self.TIM_VAR = 25         # Max number of timest variables.
        self.MAX_TVAR = 50         # Max number of timest variables + lists.
        self.EPSILON = 0.001       # Used in event_cancel.

        # Initializing Global variables:
        self.list_rank = [0]*26  # The attribute number, if any, according to which the records in list “list” are to be ranked
        self.list_size = [0]*26  # The current number of records in each list
        self.transfer = [0.0]*10  # Array for transferring into and out of the lists used in the simulation, where transfer[i] refers to attribute i of a record
        self.next_event_type = None

        # Some constants for the program
        self.LIST_EVENT = 25  # Symbolic constant for the number of the event list
        self.EVENT_TIME = 0    # Attribute number of the event time in the Event list
        self.EVENT_TYPE = 1     # Attribute number of event type in the event list
        self.INFINITY = 10^30  # A very large number

        #symbolic constants that can be used by the main program
        
        self.FIRST = 1
        self.LAST = 2
        self.INCREASING = 3
        self.DECREASING = 4

        #1 Initialising list of 26 items as Linkedlist
        self.master = [LinkedList()]*26
        self.Event_list = 25     # Event list is always number 25

        #2 Initialize system attributes
        self.sim_time = 0.0

        #Define Random variable constants
        self.MODLUS = 2147483647
        self.MULT1 = 24112
        self.MULT2 = 26143

        #Define array sizes. */
        self.LIST_SIZE= 26 #/* MAX_LIST + 1. */
        self.ATTR_SIZE= 11 #/* MAX_ATTR + 1. */
        self.SVAR_SIZE= 26 #/* MAX_SVAR + 1. */
        self.TVAR_SIZE= 51 #/* MAX_TVAR + 1. */

        self.area=[0]*self.TVAR_SIZE
        self.max=[0]*self.TVAR_SIZE
        self.min=[0]*self.TVAR_SIZE
        self.preval=[0]*self.TVAR_SIZE
        self.tlvc=[0]*self.TVAR_SIZE
        self.treset=1


        self.zrng = [       1,
        1973272912, 281629770,  20006270,1280689831,2096730329,1933576050,
        913566091, 246780520,1363774876, 604901985,1511192140,1259851944,
        824064364, 150493284, 242708531,  75253171,1964472944,1202299975,
        233217322,1911216000, 726370533, 403498145, 993232223,1103205531,
        762430696,1922803170,1385516923,  76271663, 413682397, 726466604,
        336157058,1432650381,1120463904, 595778810, 877722890,1046574445,
        68911991,2088367019, 748545416, 622401386,2122378830, 640690903,
        1774806513,2132545692,2079249579,  78130110, 852776735,1187867272,
        1351423507,1645973084,1997049139, 922510944,2045512870, 898585771,
        243649545,1004818771, 773686062, 403188473, 372279877,1901633463,
        498067494,2087759558, 493157915, 597104727,1530940798,1814496276,
        536444882,1663153658, 855503735,  67784357,1432404475, 619691088,
        119025595, 880802310, 176192644,1116780070, 277854671,1366580350,
        1142483975,2026948561,1053920743, 786262391,1792203830,1494667770,
        1923011392,1433700034,1244184613,1147297105, 539712780,1545929719,
        190641742,1645390429, 264907697, 620389253,1502074852, 927711160,
        364849192,2049576050, 638580085, 547070247]


    def list_file(self,option, list):
        ''' Place transfr into list "list".
            Update timest statistics for the list.
            option:
                FIRST place at start of list
                LAST  place at end of list
                INCREASING  place in increasing order on attribute list_rank(list)
                DECREASING  place in decreasing order on attribute list_rank(list)
                (ties resolved by FIFO) '''
        print("option: ",option)
        print("list in list_file: ",list)
        # Check if the list values are appropriate
        if(list<0 or list>self.MAX_LIST):
            print("Invalid list {} for list_file at time {}".format(list,self.sim_time))
            exit()

        # check if option values is appropriate
        if option<1 or option>4:
            print("Invalid option {} for list_file at time {}".format(option,self.sim_time))
            exit()

        if option == 1 or self.list_size[list]==0:
         # Also insert at the top if there are no elements in the list
            self.master[list].insert_at(self.transfer,0) # insert at the top
            self.master[25].print()

        elif option == 2:
            end = self.master[list].get_length()  # find the length /end of list
            self.master[list].insert_at(self.transfer,end) # insert at the end

        # Increasing order
        elif option == 3:
            i = self.list_rank[list]  # find which attribute (of data) to compare for increasing order
            value_comp = self.transfer[i]  # find which value to be compared
            itr = self.master[list].head
            index = 0

            if itr.data[i]>value_comp:  # if the first value is greater than value_comp
                self.master[list].insert_at(self.transfer,index) # insert at the top
            else:
                while itr: #lets iterate through the list
                    if ((itr.next == None) or (itr.next.data[i] > value_comp and itr.data[i]<= value_comp)): # We have reached end or value_comp is between next data and current data
                        self.master[list].insert_at(self.transfer,index+1) # insert at the next index point
                        break
                    itr = itr.next
                    index+=1
            

        # decreasing order
        elif option == 4:
            i = self.list_rank[list]  # find which attribute (of data) to compare for increasing order
            value_comp = self.transfer[i]  # find which value to be compared
            itr = self.master[list].head
            index = 0
            if itr.data[i]< value_comp:  # if the first value is less than value_comp
                self.master[list].insert_at(self.transfer,index) # insert at the top
            else:
                while (itr != None) : #lets iterate through the list
                    #print('I am here', index, itr.next)
                    if ((itr.next == None) or (itr.next.data[i] < value_comp and itr.data[i]>= value_comp)): # We have reached end or value_comp is between next data and current data
                        self.master[list].insert_at(self.transfer,index+1) # insert at the next index point
                        break
                    itr = itr.next
                    #print('I am here', index, itr.next)
                    index+=1
        else :
            print("Invalid option")

        # increment the list size
        self.list_size[list] += 1
        # Update the area under the number-in-list curve.
        self.timest(self.list_size[list], self.TIM_VAR + list)
        print("FELLLLLLLLLLLLLL")
        self.master[25].print()
        return None

    def list_remove(self, option, list):
        ''' Remove a record from list "list" and copy attributes into transfer.
            Update timest statistics for the list.
            option = FIRST remove first record in the list
            option = LAST  remove last record in the list '''
        #Raise exception is list number or option is incorrect
        if (list < 0 or list > 25) or (option != self.FIRST and option != self.LAST):
            raise Exception ("Invalid entry")

        # Print and Exit if the linkedlist is empty
        if  (self.list_size[list] <=0):
            print("underflow of list {} at time {}".format(list,self.sim_time))

        # Copy to transfer and remove the entry from the list
        len = self.master[list].get_length()
        if option == self.FIRST:
            self.transfer = self.master[list].copy_from(0)
            # print("masterrrrrrrr")
            # self.master[25].print()
            self.master[list].remove_at(0)
        else:
            self.transfer = self.master[list].copy_from(len-1)
            self.master[list].remove_at(len-1)

        #decrement the list size
        self.list_size[list] -=1

        # Update the area under the number-in-list curve.
        self.timest(self.list_size[list], self.TIM_VAR + list)  # TIM_VAR is total variables in timest
        print('Transfer has this value at end of list remove', self.transfer)

        return None

    def timing(self):
        '''Remove next event from event list, placing its attributes in transfer. Set sim_time (simulation time) to event time, transfer[1].
        Set next_event_type to this event type, transfer[2]. */'''
        # remove the first event from the event list and put it in transfer
        self.list_remove(self.FIRST,self.LIST_EVENT)
        print('Transfer has this value right now', self.transfer)

        # check for time reversal
        if self.transfer[self.EVENT_TIME] < self.sim_time:
            print('Incorrect Attempt to schedule event type {} for time {} at time{}'.format(self.transfer[self.EVENT_TYPE],self.transfer[self.EVENT_TIME],self.sim_time))
            return
        # advance simulation clock
        self.sim_time = self.transfer[self.EVENT_TIME]
        self.next_event_type = self.transfer[self.EVENT_TYPE]
        return

    def event_schedule(self,time_of_event, type_of_event):
        '''Schedule an event at time event_time of type event_type.  If attributes beyond
        the first two (reserved for the event time and the event type) are being used in the event list,
        it is the user's responsibility to place their values into the transfer array before invoking event_schedule.'''
        self.transfer[self.EVENT_TIME] = time_of_event
        self.transfer[self.EVENT_TYPE] = type_of_event
        self.list_file(self.INCREASING,self.LIST_EVENT)
        return

    def event_cancel(self,event_type):
        '''Remove the first event of type event_type from the event list, leaving its
        attributes in transfer.  If something is cancelled, event_cancel returns 1;
        if no match is found, event_cancel returns 0.'''

        # If the event list is empty, do nothing and return 0.
        if (self.list_size[self.LIST_EVENT] == 0):
            return 0

        itr = self.master[self.LIST_EVENT].head
        index = 0

        #iterate through the linked list
        while itr:
            if itr.data[self.EVENT_TYPE] == event_type: # if the event type matches
                self.transfer = self.master[self.LIST_EVENT].copy_from(index)  # put the data into transfer array
                self.master[self.LIST_EVENT].remove_at(index)    # remove the entry
                self.list_size[self.LIST_EVENT]-=1                # decrement size of event list
                self.timest(self.list_size[self.LIST_EVENT], self.TIM_VAR + self.LIST_EVENT)  # Update the area under the number-in-event-list curve
                return 1
            itr = itr.next
            index += 1
        return 0


    def sampst(self,value, variable):
        '''* Initialize, update, or report statistics on discrete-time processes:
        sum/average, max (default -1E30), min (default 1E30), number of observations
        for sampst variable "variable", where "variable":
        = 0 initializes accumulators
        > 0 updates sum, count, min, and max accumulators with new observation
        < 0 reports stats on variable "variable" and returns them in transfer:
        [1] = average of observations
        [2] = number of observations
        [3] = maximum of observations
        [4] = minimum of observations */'''
        # ivar, 
        
        # static float max[SVAR_SIZE], min[SVAR_SIZE], sum[SVAR_SIZE];
        max=[0]*self.SVAR_SIZE
        min=[0]*self.SVAR_SIZE
        sum=[0]*self.SVAR_SIZE
        num_observations=[0]*self.SVAR_SIZE

        # /* If the variable value is improper, stop the simulation. */
        if (not(variable >= -self.MAX_SVAR) and (variable <= self.MAX_SVAR)):
            print("\n%d is an improper value for a sampst variable at time %f\n", variable, self.sim_time)
            pass
                # /* Execute the desired option. */
        if(variable > 0):
            # Update
            sum[variable] += value
            if(value > max[variable]):
                max[variable] = value
            if(value < min[variable]):
                min[variable] = value
            num_observations[variable] +=1
            return 0.0

        elif(variable < 0): #Report summary statistics in transfer. */
            ivar = -variable
            self.transfer[2] = num_observations[ivar]
            self.transfer[3] = max[ivar]
            self.transfer[4] = min[ivar]
            if(num_observations[ivar] == 0):
                self.transfer[1] = 0.0
            else:
                self.transfer[1] = sum[ivar] / self.transfer[2]
            return self.transfer[1]
        
        # /* Initialize the accumulators. */
        for ivar in range (1,self.MAX_SVAR):
            sum[ivar] = 0.0
            max[ivar] = -self.INFINITY
            min[ivar] = self.INFINITY
            num_observations[ivar] = 0


    def timest(self,value, variable):
        # /* Initialize, update, or report statistics on continuous-time processes:
        # integral/average, max (default -1E30), min (default 1E30)
        # for timest variable "variable", where "variable":
        # = 0 initializes counters
        # > 0 updates area, min, and max accumulators with new level of variable
        # < 0 reports stats on variable “variable” and returns them in transfer:
        # [1] = time-average of variable updated to the time of this call
        # [2] = maximum value variable has attained
        # [3] = minimum value variable has attained
        # Note that variables TIM_VAR + 1 through TVAR_SIZE are used for automatic
        # record keeping on the length of lists 1 through MAX_LIST. */
        # int ivar;
        # static float area[TVAR_SIZE], max[TVAR_SIZE], min[TVAR_SIZE],
        # self.preval[TVAR_SIZE], tlvc[TVAR_SIZE], self.treset;
        # /* If the variable value is improper, stop the simulation. */
        #moved to global variables::>
        # area=[0]*self.TVAR_SIZE
        # max=[0]*self.TVAR_SIZE
        # min=[0]*self.TVAR_SIZE
        # self.preval=[0]*self.TVAR_SIZE
        # tlvc=[0]*self.TVAR_SIZE
        # self.treset=1
        if(not(variable >= -self.MAX_TVAR) and (variable <= self.MAX_TVAR)):
            print("\n%d is an improper value for a timest variable at time %f\n", variable, self.sim_time)
            pass
        
        # Execute the desired option.
        if(variable > 0):  #/* Update. */
            self.area[variable] += ((self.sim_time - self.tlvc[variable]) * self.preval[variable])
            #area += (self.sim_time - self.EVENT_TIME) * self.preval[variable]   
            
            if(value > self.max[variable]):
                self.max[variable] = value
            if(value < self.min[variable]):
                self.min[variable] = value
            self.preval[variable] = value
            self.tlvc[variable] = self.sim_time
            return 0.0
        
        if(variable < 0): #/* Report summary statistics in transfer. */
            ivar = -variable
            self.area[ivar] += ((self.sim_time - self.tlvc[ivar]) * self.preval[ivar])
            self.tlvc[ivar] = self.sim_time
            self.transfer[1] = self.area[ivar] / (self.sim_time - self.treset)
            self.transfer[2] = self.max[ivar]
            self.transfer[3] = self.min[ivar]
            return self.transfer[1]
       
        # Initialize the accumulators. 
        for ivar in range(1, self.MAX_TVAR):
            self.area[ivar] = 0.0
            max[ivar] = -self.INFINITY
            min[ivar] = self.INFINITY
            self.preval[ivar] = 0.0
            self.tlvc[ivar] = self.sim_time
        
        self.treset = self.sim_time
        

    def filest(self,list):
        ''' Report statistics on the length of list "list" in transfer:
        [1] = time-average of list length updated to the time of this call
        [2] = maximum length list has attained
        [3] = minimum length list has attained
        This uses timest variable TIM_VAR + list.'''
        return self.timest(0.0, -(self.TIM_VAR + list))  # need to check

    def out_sampst(self,unit, lowvar, highvar):
        #Write sampst statistics for variables lowvar through highvar on file "unit".
        # int ivar, iatrr;
        filename=unit+ '.txt'
        if(lowvar>highvar or lowvar > self.MAX_SVAR or highvar > self.MAX_SVAR):
            return
        with open(filename, 'a') as f:
            f.write( "\n sampst Number")
            f.write( "\n variable of")
            f.write( "\n number Average values Maximum")
            f.write( " Minimum")
            f.write( "\n___________________________________")
            f.write( "_____________________________________")
            for ivar in range(lowvar, highvar+1): #added 1 to the range as this is <=
                #f.write("\n\n", ivar)
                f.write("\n\n")
                f.write(str(ivar))
                self.sampst(0.00, -ivar)
            for iatrr in range( 1, 5): #added 1 to the range as this is <=
                f.write(str(iatrr))
            f.write("\n___________________________________")
            f.write("_____________________________________\n\n\n")
        

    def out_timest(self,unit, lowvar, highvar):
        #Write timest statistics for variables lowvar through highvar on file "unit".
        # int ivar, iatrr;
        filename = unit + '.txt'
        if(lowvar > highvar or lowvar > self.TIM_VAR or highvar > self.TIM_VAR ):
            return
        with open(filename, 'a') as f:
            f.write( "\n timest")
            f.write( "\n variable Time")
            f.write( "\n number average Maximum Minimum")
            f.write( "\n________________________________________________________")
            for ivar in range(lowvar, highvar+1):
                f.write( "\n\n")
                f.write(str(ivar))
                self.timest(0.00, -ivar)
            for iatrr in range(1,4):
                f.write(str(iatrr))
            f.write( "\n________________________________________________________")
            f.write( "\n\n\n")



    def out_filest(self,unit, lowlist, highlist):
        # Need to implement fprintf properly
        ''' Write timest list-length statistics for lists lowlist through highlist on
        file "unit". '''
        filename = unit + '.txt' #Rishikesh -added to standardize the code for filename
        if (lowlist>highlist or lowlist > self.MAX_LIST or highlist > self.MAX_LIST):  # if variables arent correct do not do anything
            return

        print(unit,"\n  File         Time")
        print(unit, "\n number       average          Maximum          Minimum")
        print(unit, "\n_______________________________________________________")
        for list in range(lowlist, highlist+1):
            print(unit, "\n\n", list)
            self.filest(list)
            for iatrr in range(1,4):
                print(unit, iatrr)
        print(unit, "\n_______________________________________________________")
        print(unit, "\n\n\n")
        return

    def expon(self,mean,stream):
        '''This function returns a float with an observation from an
        exponential distribution with mean “mean” (a fl oat argument).
        '''
        return -mean * math.log(self.lcgrand(stream))

    def random_integer(self,prob_distrib, stream):
        '''This function returns an int with an
        observation from a discrete probability distribution with cumulative distribution function
        values specified by the user in the float array prob_distrib.
        '''
        u = self.lcgrand(stream)

        for i in range(25):
            if(u >= prob_distrib[i]):
                return i

    def uniform(self,a, b, stream):
        '''
        This function returns a fl oat with an observation from a
        (continuous) uniform distribution between a and b
        '''
        return a + self.lcgrand(stream) * (b - a)

    def erlang(self,m, mean, stream):
        '''This function returns a float with an observation
        from an m-Erlang distribution with mean “mean” using random-number stream
        "stream"
        '''
        mean_exponential = mean / m
        sum = 0.0
        for i in range(m):
            sum += self.expon(mean_exponential, stream)
        return sum

    def lcgrand(self,stream):
        '''
        This is the random-number generator used by simlib, a function
        returning a float with an observation from a (continuous) uniform distribution
        between 0 and 1, using stream.
        '''
        zi     = self.zrng[stream]
        lowprd = (zi & 65535) * self.MULT1
        hi31   = (zi >> 16) * self.MULT1 + (lowprd >> 16)
        zi     = ((lowprd & 65535) - self.MODLUS) + ((hi31 & 32767) << 16) + (hi31 >> 15)
        if (zi < 0): 
            zi += self.MODLUS
        lowprd = (zi & 65535) * self.MULT2
        hi31   = (zi >> 16) * self.MULT2 + (lowprd >> 16)
        zi     = ((lowprd & 65535) - self.MODLUS) + ((hi31 & 32767) << 16) + (hi31 >> 15)
        if (zi < 0):
            zi += self.MODLUS
        self.zrng[stream] = zi
        return (zi >> 7 | 1) / 16777216.0

    def lcgrandst(self,zset, stream):
        '''
        This function sets the random-number seed for
        stream "stream" to the long argument zset.
        '''
        self.zrng[stream] = zset

    def lcgrandgt(self,stream):
        '''
        This function returns a long int with the current underlying integer
        for the random-number generator for stream
        '''
        return self.zrng[stream]

if __name__ == "__main__":
    s = simlibPY()
    a = s.lcgrand(1)
    #lst = s.lcgrandst(2334435,1)
    lgt = s.lcgrandgt(1)
    ex = s.expon(5,1)
    u = s.uniform(1,4,1)
    e = s.erlang(2,5,1)
    timst = s.timest(value=-1, variable=-8)
    smpst= s.sampst(value=-1, variable=-6)
    s.out_timest('unit', lowvar=4, highvar=9)
    s.out_sampst('unit', lowvar=4, highvar=9)
    print("lcgrand: ",a)
    #print("lcgrandst: ",lst)
    print("lcgrandgt: ",lgt)
    print("expon: ",ex)
    print("uniform: ",u)
    print("erlang: ",e)
    print("timest", timst)
    print("sampst", smpst)
    s.master[25].print()
    s.list_file(3,25)
    s.master[25].print()
    print(s.area)
    print(s.max)
    print(s.preval)

